/**
 * This file is part of Turbine
 * http://github.com/SirPepe/Turbine
 * 
 * Copyright (c) 2010 Christian "Schepp" Schaefer, http://twitter.com/derSchepp
 * Licensed under GNU LGPL 3, see http://www.gnu.org/licenses/
 * 
 * This extension adds Turbine-.cssp-file support and code hinting to Dreamweaver 6+
 * Install via Extension Manager.
 * 
 */