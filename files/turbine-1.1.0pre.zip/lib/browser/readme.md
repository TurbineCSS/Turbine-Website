Turbine-Browser
===============

Turbine's browser sniffer

http://github.com/SirPepe/Turbine-Browser
