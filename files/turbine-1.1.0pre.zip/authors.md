Authors ordered by first contribution
=====================================

  - [Peter Kröner][1]
  - [Christian Schaefer][2]
  - [Christian Hayungs][10]
  - [Frank Bültge][3]
  - [Alexander Rösel][9]
  - [Karsten Bellwied][11]



Turbine uses parts of the following projects:
=============================================

  - [ie7-js][4] by Dean Edwards
  - [cssmin.php][5] by Joe Scylla
  - [Whatever:hover][6] by Peter Nederlof
  - [IE5.5+ PNG Alpha Fix][7] by Angus Turnbull
  - [Box Sizing Behavior][8] by Erik Arvidsson


  [1]: http://www.peterkroener.de
  [2]: http://twitter.com/derSchepp
  [3]: http://bueltge.de
  [4]: http://code.google.com/p/ie7-js/
  [5]: http://code.google.com/p/cssmin/
  [6]: http://www.xs4all.nl/~peterned/
  [7]: http://www.twinhelix.com
  [8]: http://webfx.eae.net/dhtml/boxsizing/boxsizing.html
  [9]: http://twitter.com/traxmaxx
  [10]: http://hayungs.de/
  [11]: http://zierfischkaefig.de/
